# Lincoln

"A Deep Learning library by the people, for the people."

![](lincoln.png)

## Description

"Lincoln" is a minimal Deep Learning library accompanying the book "Deep Learning From Scratch", which will be published by O'Reilly in August 2019.

It is intended for beginners who want to understand the key components of how Deep Learning works by walking through a clean, minimal implementation.
